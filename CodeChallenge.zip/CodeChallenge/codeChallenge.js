try {
  var readline = require('readline-sync');

var operation = readline.question("? ");
var searchOp;
//regex to search for the operator 
const regex = /\s[+\-\/*]\s/g;
searchOp = operation.search(regex) + 1;

//Declaration of the global variables to use for the to operands
var operationLength = operation.length;
var firstNum = operation.substring(0,searchOp);
var checkFirstMix = firstNum.includes("_");
var checkFirstFract = firstNum.includes("/");
var sendFirstNumerator;
var sendSecondNumerator;
var sendFirstDenom;
var sendSecondDenom;
var sendOp;
var intFirstWhole;
var intSecondWhole;
var intFirstNumerator;
var intSecondNumerator;
var intFirstDenom;
var intSecondDenom;
var secondNum = operation.substring(searchOp+2,operationLength);
var checkSecondMix = secondNum.includes("_");
var checkSecondFract = secondNum.includes("/");
var finalNumerator;
var finalDenom;
var finalWhole;
var flagWhole = 0;

//First cycle is with the first operand as mixNumber
if(checkFirstMix){
    
    mixedFirstNumber(firstNum);
	
	//next is to check all possible scenarios for first mixed number and the second any of the tree possibilities.
    if(checkSecondMix){

        mixedSecondNumber(secondNum);

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);

    }else if(checkSecondFract){
        
        fractSecondNum(secondNum);

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);
    }else{
        var numSecond = parseInt(secondNum);
        sendSecondNumerator = (numSecond * intFirstDenom);
        sendSecondDenom = intFirstDenom;

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);
    }

    sendOp = operation[searchOp];
	
//now check with first number as fraction.
}else if(checkFirstFract){

    fractFirstNum(firstNum);
	
	//all possible tree scnenarios for this case
    if(checkSecondMix){

        mixedSecondNumber(secondNum);

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);

    }else if(checkSecondFract){
        
        fractSecondNum(secondNum);

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);
    }else{
        var numSecond = parseInt(secondNum);
        sendSecondNumerator = (numSecond * sendFirstDenom);
        sendSecondDenom = sendFirstDenom;

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);
    }

    sendOp = operation[searchOp];

//Last scenario for the number is to be a normal whole number
}else{

    var numFirst = parseInt(firstNum);
    
	//all tree scenarios for this case.
    if(checkSecondMix){

        mixedSecondNumber(secondNum);

        sendFirstNumerator = (numFirst * intSecondDenom);
        sendFirstDenom = intSecondDenom;

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);

    }else if(checkSecondFract){
        
        fractSecondNum(secondNum);

        sendFirstNumerator = (numFirst * sendSecondDenom);
        sendFirstDenom = sendSecondDenom;

        sendOp = operation[searchOp];
        calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp);
        
    }else{
        var numSecond = parseInt(secondNum);
        sendOp = operation[searchOp];
        calculationNormal(numFirst,numSecond,sendOp);
    }

}

}
//catch errors
catch(err) {
  console.log("Unable to do the operation given. Please verify.");
}

function simplify(numerator,denominator,flag){
    var commonDenom = function commonDenom(a,b){
      return b ? commonDenom(b, a%b) : a;
    };
    commonDenom = commonDenom(numerator,denominator);
    var num = numerator/commonDenom;
	
    var denom = denominator/commonDenom;
	var denomPos;
	
	if(denom<0){
		denomPos = (denom * -1);
	}else{
		denomPos = denom;
	}

    if((num>denomPos) && flag == 0){
		flagWhole = 1;
        finalWhole = parseInt(num/denom);
        var decimal = (num/denom) - finalWhole;
		if(decimal != 0){
			finalNumerator = num - (denom * finalWhole);
			if(finalNumerator<0){
				finalNumerator = finalNumerator * -1;
			}
			finalDenom = denom;
			if(finalDenom<0){
				finalDenom = finalDenom * -1;
			}
		}else{
			flagWhole = 2;
		}
    }else{
		finalNumerator = num;
        finalDenom = denom;
	}
  }

function calculationNormal(numFirst,numSecond,sendOp){
    switch(sendOp){
        case "+":
            finalWhole = numFirst + numSecond;
            break;
        case "-":
            finalWhole = numFirst - numSecond;
            break;
        case "/":
            finalWhole = numFirst / numSecond;
            break;
        case "*":
            finalWhole = numFirst * numSecond;
            break;
    }
	//throwing error if calculations cant be made with the input.
	if(isNaN(finalWhole)) throw "Unable to do the operation given. Please verify.";
    console.log("= " + finalWhole);
}

function calculation(sendFirstNumerator,sendFirstDenom,sendSecondNumerator,sendSecondDenom,sendOp){
    switch(sendOp){
        case "+":
            if(sendSecondDenom > sendFirstDenom){
				if(sendSecondDenom % sendFirstDenom == 0){
					sendFirstNumerator = sendFirstNumerator * (sendSecondDenom / sendFirstDenom);
					finalNumerator = sendFirstNumerator + sendSecondNumerator;
					finalDenom = sendSecondDenom;
				}else{
					sendFirstNumerator = sendFirstNumerator * sendSecondDenom;
					sendFirstDenom = sendFirstDenom * sendSecondDenom;
					sendSecondNumerator = sendSecondNumerator * (sendFirstDenom/sendSecondDenom);
					sendSecondDenom = sendSecondDenom * (sendFirstDenom/sendSecondDenom);
					
					finalNumerator = sendFirstNumerator + sendSecondNumerator;
					finalDenom = sendSecondDenom;				
				}
            }else{
				if(sendFirstDenom % sendSecondDenom == 0){
					sendSecondNumerator = sendSecondNumerator * (sendFirstDenom / sendSecondDenom);
					finalNumerator = sendFirstNumerator + sendSecondNumerator;
					finalDenom = sendFirstDenom;
				}else{
					sendFirstNumerator = sendFirstNumerator * sendSecondDenom;
					sendFirstDenom = sendFirstDenom * sendSecondDenom;
					sendSecondNumerator = sendSecondNumerator * (sendFirstDenom/sendSecondDenom);
					sendSecondDenom = sendSecondDenom * (sendFirstDenom/sendSecondDenom);
					
					finalNumerator = sendFirstNumerator + sendSecondNumerator;
					finalDenom = sendSecondDenom;
				}
            }
            break;
        case "-":
            if(sendSecondDenom > sendFirstDenom){
				if(sendSecondDenom % sendFirstDenom == 0){
					sendFirstNumerator = sendFirstNumerator * (sendSecondDenom / sendFirstDenom);

					finalNumerator = sendFirstNumerator - sendSecondNumerator;
					finalDenom = sendSecondDenom;
				}else{
					sendFirstNumerator = sendFirstNumerator * sendSecondDenom;
					sendFirstDenom = sendFirstDenom * sendSecondDenom;
					sendSecondNumerator = sendSecondNumerator * (sendFirstDenom/sendSecondDenom);
					sendSecondDenom = sendSecondDenom * (sendFirstDenom/sendSecondDenom);
					
					finalNumerator = sendFirstNumerator - sendSecondNumerator;
					finalDenom = sendSecondDenom;
				}
            }else{
				if(sendFirstDenom % sendSecondDenom == 0){
					sendSecondNumerator = sendSecondNumerator * (sendFirstDenom / sendSecondDenom);

					finalNumerator = sendFirstNumerator - sendSecondNumerator;
					finalDenom = sendFirstDenom;
				}else{
					sendFirstNumerator = sendFirstNumerator * sendSecondDenom;
					sendFirstDenom = sendFirstDenom * sendSecondDenom;
					sendSecondNumerator = sendSecondNumerator * (sendFirstDenom/sendSecondDenom);
					sendSecondDenom = sendSecondDenom * (sendFirstDenom/sendSecondDenom);
					
					finalNumerator = sendFirstNumerator - sendSecondNumerator;
					finalDenom = sendSecondDenom;
				}
            }
            break;
        case "/":
            finalNumerator = sendFirstNumerator * sendSecondDenom;
            finalDenom = sendFirstDenom * sendSecondNumerator;
            break;
        case "*":
            finalNumerator = sendFirstNumerator * sendSecondNumerator;
            finalDenom = sendFirstDenom * sendSecondDenom;
            break;
    }
    simplify(finalNumerator,finalDenom,0);
	//throwing error if calculations cant be made with the input.
	if(flagWhole == 1){
			if(isNaN(finalWhole) || isNaN(finalNumerator) || isNaN(finalDenom)) throw "Unable to do the operation given. Please verify.";
			console.log("= " + finalWhole + "_" + finalNumerator + "/" + finalDenom);
	}else if(flagWhole == 2){
		if(isNaN(finalWhole)) throw "Unable to do the operation given. Please verify.";
		console.log("= " + finalWhole);
	}else{
		if(finalNumerator == finalDenom){
			if(isNaN(finalNumerator)) throw "Unable to do the operation given. Please verify.";
			console.log("= " + finalNumerator);
		}else{
			if(isNaN(finalNumerator)) throw "Unable to do the operation given. Please verify.";
			console.log("= " + finalNumerator + "/" + finalDenom);
		}
	}
}

function mixedFirstNumber(firstNum){
        
    var sch = firstNum.search("_");
    var schDiag = firstNum.search("/");
    var wholeNum = firstNum.substring(0,sch);
    var numerator = firstNum.substring(sch+1,schDiag);
    var denom = firstNum.substring(schDiag+1,firstNum.length);

    intFirstWhole = parseInt(wholeNum);
    intFirstNumerator = parseInt(numerator);
    intFirstDenom = parseInt(denom);

    sendFirstNumerator = (intFirstWhole * intFirstDenom) + intFirstNumerator;
    sendFirstDenom = intFirstDenom;
}

function mixedSecondNumber(secondNum){
    
    var schSecond = secondNum.search("_");
    var schDiagSecond = secondNum.search("/");
    var wholeNumSecond = secondNum.substring(0,schSecond);
    var numeratorSecond = secondNum.substring(schSecond+1,schDiagSecond);
    var denomSecond = secondNum.substring(schDiagSecond+1,secondNum.length);

    intSecondWhole = parseInt(wholeNumSecond);
    intSecondNumerator = parseInt(numeratorSecond);
    intSecondDenom = parseInt(denomSecond);
    
    sendSecondNumerator = (intSecondWhole * intSecondDenom) + intSecondNumerator;
    sendSecondDenom = intSecondDenom;
}

function fractFirstNum(firstNum){
    var schDiag = firstNum.search("/");
    var numerator = firstNum.substring(0,schDiag);
    var denom = firstNum.substring(schDiag+1,firstNum.length);

    sendFirstNumerator = parseInt(numerator);
    sendFirstDenom = parseInt(denom);
}

function fractSecondNum(secondNum){
    
    var schDiagSecond = secondNum.search("/");
    var numeratorSecond = secondNum.substring(0,schDiagSecond);
    var denomSecond = secondNum.substring(schDiagSecond+1,secondNum.length);

    sendSecondNumerator = parseInt(numeratorSecond);
    sendSecondDenom = parseInt(denomSecond);
}